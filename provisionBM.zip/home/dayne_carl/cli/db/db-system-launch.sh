function db-system-launch-persist ()
{
  #Expecting the name of of the variable as $1 and the value as $2
  if [ -z "$1" ]; then echo Exiting: db-system-launch-persist did not receive the variable name; exit; fi
  if [ -z "$2" ]; then echo Exiting: db-system-launch-persist did not receive the variable value; exit; fi
  
  varname="$1"
  varvalue="$2"
  
  grep "$varname" $CLI_DB/db-system-launch-found-variables >null
  if [ $? = 0 ]
  then 
    cat $CLI_DB/db-system-launch-found-variables | grep -v "$varname" >$CLI_DB/resp/db-system-launch-found-variables
    mv $CLI_DB/resp/db-system-launch-found-variables $CLI_DB/db-system-launch-found-variables
  fi
  
  echo "export $(echo "$varname")=$(echo \""$varvalue"\")" >>$CLI_DB/db-system-launch-found-variables
  echo; echo The variable "$varname" with value "$varvalue" has been stored.; echo
}
  
function prompt-adminPassword ()
{
  clear
  read -s -p "Please enter the SYS admin password: " adminPassword; echo; db-system-launch-persist foundB64adminPassword "$( echo $adminPassword |base64 )"
}
  
function prompt-availabilityDomain ()
{
  read -p "Please enter the availability domain: " foundAvailabilityDomain echo; db-system-launch-persist foundAvailabilityDomain "$foundAvailabilityDomain"
}
  
function prompt-availabilityDomain-list ()
{
  iam-availability-domain-list
  echo; echo AD List:; echo
  cat $CLI/resp/iam-availability-domain-list-resp |jq -r '.data[]."name"'
  echo
  prompt-availabilityDomain
}
  
function prompt-compartmentId ()
{
  read -p "Please enter the compartment ID: " foundCompartmentId echo; db-system-launch-persist foundCompartmentId "$foundCompartmentId"
}
  
function prompt-compartmentId-list ()
{
  iam-compartment-list
  read -p "Please enter a unique partial or complete Compartment name: " compartmentName; echo; com-retrieve-id-from-data-contains-name  "$compartmentName" "$CLI/resp/iam-compartment-list-resp"
  export foundCompartmentId=$foundId
  db-system-launch-persist foundCompartmentId "$foundCompartmentId"
}
  
function prompt-subnetId ()
{
  read -p "Please enter the subnet ID: " foundSubnetId; echo; db-system-launch-persist foundSubnetId "$foundSubnetId"
}
  
function prompt-subnetId-list ()
{
  network-vcn-list "$foundCompartmentId"
  echo; echo VCN List:; echo
  cat $CLI/resp/network-vcn-list-resp |jq -r '.data[]."display-name"'
  echo  
  read -p "Please enter the VCN name: " vcnName; echo; com-retrieve-id-from-data-equals-display-name "$vcnName" $CLI/resp/network-vcn-list-resp
  export foundVcnId=$foundId
  db-system-launch-persist foundVcnId "$foundVcnId"

  network-subnet-list "$foundCompartmentId" "$foundVcnId"
  echo; echo Subnet List:; echo
  cat $CLI/resp/network-subnet-list-resp |jq -r '.data[]."display-name"'
  echo
  read -p "Please enter a subnet name: " subnetName; echo; com-retrieve-id-from-data-equals-display-name  "$subnetName" $CLI/resp/network-subnet-list-resp
  export foundSubnetId=$foundId
  db-system-launch-persist foundSubnetId "$foundSubnetId"
}
  
function prompt-dbName ()
{
  read -p "Please enter the DB name (up to eight alphanumeric characters - no spaces) : " foundDbName; echo; db-system-launch-persist foundDbName "$foundDbName"
}
  
function db-system-launch ()
{
  function pre-launch ()
  {
    function convert-varRecords () 
    { 
    # Expecting file name as $1
        fileName=$1
        while read -r line
        do 
          varname=$(echo $line |cut -f 1 -d '=')
          varname="\"$varname\":" 
          varvalue=$(echo $line |cut -f 2 -d '=')
          if [ $line = $(cat $CLI_DB/lastVarRecord) ]
          then      varvalue="\"$varvalue\""
          else      varvalue="\"$varvalue\","
          fi
      
          echo "$varname $varvalue"
        done <$fileName >>$CLI_DB/db-system-launch-parameters; 
      }
  
      # Begin Pre-Launch  
      truncate -s 0 $CLI_DB/db-system-launch-parameters
      env |grep ^V_ |sed 's/^V_//' |sort >$CLI_DB/varRecords
      tail -1 $CLI_DB/varRecords >$CLI_DB/lastVarRecord
      head -n -1 $CLI_DB/varRecords >$CLI_DB/firstVarRecords
  
      echo "{" >>$CLI_DB/db-system-launch-parameters
      convert-varRecords $CLI_DB/firstVarRecords
      convert-varRecords $CLI_DB/lastVarRecord
      echo "}" >>$CLI_DB/db-system-launch-parameters
  }
  
  function launch ()
  {
      oci db system launch --admin-password $(echo $foundB64adminPassword |base64 -d) --from-json file://$CLI_DB/db-system-launch-parameters --wait-for-state PROVISIONING --wait-for-state FAILED >$CLI_DB/resp/db-system-launch-resp
      export foundLifecycleState=$(cat $CLI_DB/resp/db-system-launch-resp |jq -r '.data."lifecycle-state"')
      if [ $foundLifecycleState = FAILED ]; then echo Exiting: db-system-launch failed; fi
  }
  
  function post-launch ()
  {
      export foundDbId=$(cat $CLI_DB/resp/db-system-launch-resp |jq -r '.data.id' )
      db-system-launch-persist foundDbId "$foundDbId"
      export foundHostName=$(cat $CLI_DB/resp/db-system-launch-resp |jq -r '.data.hostname' )
      export foundDomain=$(cat $CLI_DB/resp/db-system-launch-resp |jq -r '.data.domain' )
      export foundFQDN=$foundHostName.$foundDomain
      export foundServiceName=$V_dbUniqueName.$foundDomain
      export foundListenerPort=$(cat $CLI_DB/resp/db-system-launch-resp |jq -r '.data."listener-port"')
      db-system-launch-persist foundFQDN "$foundFQDN"
      db-system-launch-persist foundListenerPort "$foundListenerPort"
      db-system-launch-persist foundServiceName "$foundServiceName"
  }
  
    # Begin db-system-launch
  
      pre-launch 
      launch 
      post-launch
}
  
function db-system-get-state ()
{
    db-system-get $foundDbId
   export foundLifecycleState=$(cat $CLI/resp/db-system-get-resp |jq -r '.data."lifecycle-state"')
    echo Lifecycle State is $foundLifecycleState
}
  
function db-system-validate ()
{
  function get_IpAddresses ()
  {
    db-node-list "$foundCompartmentId" "$foundDbId"
    export foundVnicId=$(cat $CLI/resp/db-node-list-resp |jq -r '.data[]."vnic-id"')
    network-vnic-get $foundVnicId     
    export foundPublicIp=$(cat $CLI/resp/network-vnic-get-resp |jq -r '.data."public-ip"')
    export foundPrivateIp=$(cat $CLI/resp/network-vnic-get-resp |jq -r '.data."private-ip"')
    db-system-launch-persist foundPublicIp "$foundPublicIp"
    db-system-launch-persist foundPrivateIp "$foundPrivateIp"
  }

  function ssh-connection ()
  {
     now=$(date +"%Y-%m-%d-%T") 
     cp -p $HOME/.ssh/config $HOME/.ssh/config-$now

     cat <<EOF >>$HOME/.ssh/config
     Host $foundDbName
       IdentityFile $HOME/.ssh/privateKey
       User opc
EOF

     if [ $foundPublicIp = null ]
     then
       echo "     Hostname $foundPrivateIp" >>$HOME/.ssh/config
       echo "     ProxyJump BASTION"        >>$HOME/.ssh/config
     else
       echo "     Hostname $foundPublicIp"  >>$HOME/.ssh/config
     fi

     echo "Reply Yes to accept the host name key when prompted"
 
     ssh $foundDbName 'exit' # Accept Keys ; echo
     wait $!; 
     echo "Connected to the DB server via SSH" 
  }
    
  function sqlplus-connection ()
  {
    cat <<EOF >$CLI_DB/sqlplus-script
     sqlplus system/$(echo $foundB64adminPassword |base64 -d)@$foundFQDN:$foundListeningPort/$foundServiceName <<EOSP
      set head off pages 50
      select 'Hello from a sqlplus session' from dual;
      show parameter db_name
EOSP
EOF
     scp $CLI_DB/sqlplus-script $foundDbName:/tmp
     ssh $foundDbName <<EOS
      sudo su - grid
      bash /tmp/sqlplus-script; exit
      exit
EOS
echo
  }
    # Begin db-system-validate
    get_IpAddresses
    ssh-connection
    sqlplus-connection
}

  #---------------------------------------------------------------------------------------
  # *** Begin ***
  # Expecting function name as $1 
  export var_function=$1; 
  
  source $CLI_DB/db-system-launch-assigned-variables
  clear;
  
  if [ $var_function = prompt-adminPassword ]; then prompt-adminPassword; fi
  if [ $var_function = prompt-availabilityDomain ]; then prompt-availabilityDomain; fi
  if [ $var_function = prompt-availabilityDomain-list ]; then prompt-availabilityDomain-list; fi
  if [ $var_function = prompt-compartmentId ]; then prompt-compartmentId; fi
  if [ $var_function = prompt-compartmentId-list ]; then prompt-compartmentId-list; fi
  if [ $var_function = prompt-subnetId ]; then prompt-subnetId; fi
  if [ $var_function = prompt-subnetId-list ]; then prompt-subnetId-list; fi
  if [ $var_function = prompt-dbName ]; then prompt-dbName; fi
  if [ $var_function = db-system-launch ]; then db-system-launch; fi
  if [ $var_function = db-system-get-state ]; then db-system-get-state ; fi
  if [ $var_function = db-system-validate ]; then db-system-validate ; fi
  
