
function setup-ggmp21 ()
{
  cd; touch migrate-mp19c.vars
  if [ -f ~/.bashrc ]
  then :
  else
  cat <<EOF >>~/.bashrc
    if [ -f /etc/bashrc ]; then . /etc/bashrc; fi
    set -o vi
    source migrate-mp19c.vars
EOF
  fi
  
  source ~/.bashrc
  #-------
  
  if [ -f ~/.bash_profile ]
  then :
  else
    cat <<EOF >>.bash_profile
    if [ -f ~/.bashrc ]; then . ~/.bashrc; fi
EOF
  fi

  chmod 600 ~/.b*
  #--------------
  
  if [ -z $PSSWRD ]
  then
    cat <<EOF >>~/.bashrc
    export PSSWRD=YOurPwd123_#
EOF
  fi
  
  cat <<EOF >>.bashrc
    export ORACLE_HOME=$(find / -name instantclient 2>null)
    export OGG_HOME=$(cat /u02/deployments/ServiceManager/etc/conf/deploymentRegistry.dat | jq -r '.ServiceManager.oggHome')
    export OGG_VAR_HOME=\$OGG_HOME/var
    export PATH=\$OGG_HOME/bin:\$ORACLE_HOME/bin:\$PATH
    export LD_LIBRARY_PATH=\$OGG_HOME/lib:\$ORACLE_HOME/lib:\$LD_LIBRARY_PATH
EOF

  source .bashrc
}

function show-extract-status ()
{
  echo "obey show-ggmp-extract.oby" |adminclient 
}

function show-ocigg-extract-status ()
{
  echo "obey show-ocigg-extract.oby" |adminclient 
}

function show-replicat-status ()
{
  echo "obey show-ggmp-replicat.oby" |adminclient 
}

function show-ocigg-replicat-status ()
{
  echo "obey show-ocigg-replicat.oby" |adminclient 
}

function stop-ggmp ()
{ 
  echo "obey stop-ggmp.oby" |adminclient 
}

function stop-ocigg-replicat()
{
  echo "obey stop-ocigg-replicat.oby" |adminclient 
}

function restart-ocigg-replicat()
{
  echo "obey restart-ocigg-replicat.oby" |adminclient 
}

function start-ocigg-replicat()
{
  echo "obey start-ocigg-replicat.oby" |adminclient 
}

function remove-ocigg-replicat-parm ()
{ 
  cd $TNS_ADMIN/conf/ogg
  grep HANDLECOLLISIONS $OCIGG_REPLICAT_NAME.prm >null
  if [ $? = 0 ]
  then 
    now=$(date +"%Y-%m-%d-%T")
    cp $OCIGG_REPLICAT_NAME.prm $OCIGG_REPLICAT_NAME.prm-$now
    grep -iv HANDLECOLLISIONS $OCIGG_REPLICAT_NAME.prm >$OCIGG_REPLICAT_NAME.prm.nohandle
    mv $OCIGG_REPLICAT_NAME.prm.nohandle $OCIGG_REPLICAT_NAME.prm
  fi
}

#function copy-extract-parms ()
#{
# scp GGMP19:'$TNS_ADMIN/conf/ogg/$GGMP_EXTRACT.prm' .
# scp $GGMP_EXTRACT.prm GGMP21:'$TNS_ADMIN/conf/ogg'
#}

function prompt-for-ggmp-variables ()
{
#Assume the GGMP ogg-credentials.json file has the correct credentials
 cd;
 if [ -f ggmp-vars ]; then rm ggmp-vars; touch ggmp-vars; fi

 export GGMP_IP=$(ssh GGMP19 'hostname -I' 2>null )
 export GGMP_PSSWRD=$(ssh GGMP19 'cat ogg-credentials.json |jq -r '.credential' ' 2>null )
 export GGMP_USER=$(ssh GGMP19 'cat ogg-credentials.json |jq -r '.username' ' 2>null )
 export GGMP_DEPLOYMENT=$(ssh GGMP19 'echo $TNS_ADMIN |cut -f 4 -d '/'' 2>null )
 echo export GGMP_IP=$GGMP_IP >>ggmp-vars
 echo export GGMP_PSSWRD=$GGMP_PSSWRD >>ggmp-vars
 echo export GGMP_USER=$GGMP_USER >>ggmp-vars
 echo export GGMP_DEPLOYMENT=$GGMP_DEPLOYMENT >>ggmp-vars

 read -p "Please enter the case-sensitive GGMP extract name : " GGMP_EXTRACT_NAME; echo export GGMP_EXTRACT_NAME=$GGMP_EXTRACT_NAME >>ggmp-vars; 
 read -p "Please enter the case-sensitive GGMP replicat name : " GGMP_REPLICAT_NAME; echo export GGMP_REPLICAT_NAME=$GGMP_REPLICAT_NAME >>ggmp-vars; 
}

function persist-ggmp-variables ()
{
  cd;
  source ggmp-vars
  if [ -f migrate-mp19c.vars ]
  then
    grep GGMP migrate-mp19c.vars >null
    if [ $? = 0 ]
    then 
      grep -v GGMP migrate-mp19c.vars >temp-migrate-mp19c.vars
      mv temp-migrate-mp19c.vars migrate-mp19c.vars
    fi
    
    cat ggmp-vars >>migrate-mp19c.vars
  else
    cp ggmp-vars migrate-mp19c.vars
  fi

  get-source-pdb-name
  get-target-pdb-name
}
 
function prompt-for-ocigg-variables ()
{
  cd; 
  if [ -f ocigg-vars ]; then rm ocigg-vars; touch ocigg-vars; fi
  read -p "Please enter the Native GG FQDN : " OCIGG_FQDN; echo export OCIGG_FQDN=$OCIGG_FQDN >>ocigg-vars;
  read -p "Please enter the Native GG Username : " OCIGG_USER; echo export OCIGG_USER=$OCIGG_USER >>ocigg-vars;
  read -p "Please enter the Native GG Password : " OCIGG_PSSWRD; echo export OCIGG_PSSWRD=$OCIGG_PSSWRD >>ocigg-vars;
}

function persist-ocigg-variables ()
{
# Assumes ggmp variables are in place
  cd;
  source ocigg-vars
  export OCIGG_IP=$(dig $OCIGG_FQDN +short)
  echo export OCIGG_IP=$OCIGG_IP >>ocigg-vars

  echo export OCIGG_EXTRACT_NAME=OCIGGE1 >>ocigg-vars
  echo export OCIGG_REPLICAT_NAME=OCIGGR1 >>ocigg-vars

  if [ -f migrate-mp19c.vars ]
  then 
    grep  OCIGG migrate-mp19c.vars >null
    if [ $? = 0 ] 
    then 
      grep -v OCIGG migrate-mp19c.vars >temp-migrate-mp19c.vars
      mv temp-migrate-mp19c.vars migrate-mp19c.vars
    fi  
        
    cat ocigg-vars >>migrate-mp19c.vars
  else
    cp ocigg-vars migrate-mp19c.vars
  fi  
}

function find-ocigg-deployment ()
{
  cd; 
  source migrate-mp19c.vars
  cat <<EOF >find-ocigg-Deployment.oby
  CONNECT https://$OCIGG_IP deployment xyz as $OCIGG_USER password $OCIGG_PSSWRD !
EOF

  export OCIGG_DEPLOYMENT=$(echo "obey find-ocigg-Deployment.oby" |adminclient 2>null |grep " -" |sed 's/ \- //')
  grep OCIGG_DEPLOYMENT migrate-mp19c.vars >null

  if [ $? = 0 ]
  then 
    grep -v OCIGG_DEPLOYMENT migrate-mp19c.vars >temp-migrate-mp19c.vars
    mv temp-migrate-mp19c.vars migrate-mp19c.vars
  fi
  echo export OCIGG_DEPLOYMENT=$OCIGG_DEPLOYMENT >>migrate-mp19c.vars
}

function connect-ocigg ()
{
#Performed once on GGMP21 server after prompts and found-deployment to create oby file
  echo "obey connect-ocigg.oby" |adminclient
}

function create-ggmp-obey-files ()
{
  cat <<EOF >~/connect-ggmp.oby
  allownested
  connect https://$GGMP_IP deployment $GGMP_DEPLOYMENT as $GGMP_USER password $GGMP_PSSWRD ! 
EOF

  cat <<EOF >edit-ggmp-params.oby
   obey connect-ggmp.oby
   edit PARAMS $GGMP_EXTRACT_NAME.prm
EOF

  cat <<EOF >stop-ggmp.oby
   allownested
   obey dblogin-ggmp-target.oby
   STOP REPLICAT $GGMP_REPLICAT_NAME
   obey dblogin-ggmp-source.oby
   STOP EXTRACT $GGMP_EXTRACT_NAME
EOF

  cat <<EOF >show-ggmp-extract.oby
   allownested
   obey connect-ggmp.oby
   INFO EXTRACT $GGMP_EXTRACT_NAME, showch
EOF

  cat <<EOF >show-ggmp-replicat.oby
   allownested
   obey connect-ggmp.oby
   INFO replicat $GGMP_REPLICAT_NAME, showch
EOF

  cat <<EOF >dblogin-ggmp-source.oby
   allownested
   obey connect-ggmp.oby
   DBLOGIN USERIDALIAS SOURCE
EOF

  cat <<EOF >dblogin-ggmp-target.oby
   allownested
   obey connect-ggmp.oby
   DBLOGIN USERIDALIAS TARGETPDB
EOF

  cat <<EOF >start-ggmp-replicat.oby
   allownested
   obey dblogin-ggmp-target.oby
   start replicat $GGMP_REPLICAT_NAME
EOF

  cat <<EOF >stop-ggmp-replicat.oby
   allownested
   obey dblogin-ggmp-target.oby
   stop replicat $GGMP_REPLICAT_NAME
EOF

  cat <<EOF >start-ggmp-extract.oby
   allownested
   obey dblogin-ggmp-source.oby
   start extract $GGMP_EXTRACT_NAME
EOF
}

function create-ocigg-obey-files ()
{
  cat <<EOF >~/connect-ocigg.oby
  allownested
  connect https://$OCIGG_IP deployment $OCIGG_DEPLOYMENT as $OCIGG_USER password $OCIGG_PSSWRD ! 
EOF

  cat <<EOF >edit-ocigg-extract-params.oby
   allownested
   obey connect-ocigg.oby
   EDIT PARAMS $OCIGG_EXTRACT_NAME.prm
EOF

  cat <<EOF >edit-ocigg-replicat-params.oby
   allownested
   obey connect-ocigg.oby
   EDIT PARAMS $OCIGG_REPLICAT_NAME.prm
EOF

  cat <<EOF >info-ocigg.oby
   allownested
   obey dblogin-source.oby
   stats extract $OCIGG_EXTRACT_NAME, LATEST, TABLE PDB1.GGRTS_BLOG_USER.COUNTRIES
   info extract $OCIGG_EXTRACT_NAME, showch
   lag $OCIGG_EXTRACT_NAME
   info exttrail gg
   obey dblogin-target.oby
   info heartbeat
   stats replicat $OCIGG_REPLICAT_NAME, TABLE PDB1.GGRTS_BLOG_USER.COUNTRIES
   info replicat $OCIGG_REPLICAT_NAME, showch
   lag $OCIGG_REPLICAT_NAME
   lag replicat $OCIGG_REPLICAT_NAME
EOF

  cat <<EOF >dblogin-source.oby
   allownested
   obey connect-ocigg.oby
   DBLOGIN USERIDALIAS SOURCE
EOF

  cat <<EOF >dblogin-target.oby
   allownested
   obey connect-ocigg.oby
   DBLOGIN USERIDALIAS TARGETPDB
EOF

  cat <<EOF >start-ocigg-replicat.oby
   allownested
   obey dblogin-target.oby
   start replicat $OCIGG_REPLICAT_NAME
EOF

  cat <<EOF >restart-ocigg-replicat.oby
   allownested
   obey dblogin-target.oby
   stop replicat $OCIGG_REPLICAT_NAME
   start replicat $OCIGG_REPLICAT_NAME
   shell sleep 10
   info replicat $OCIGG_REPLICAT_NAME
EOF

  cat <<EOF >stop-ocigg-replicat.oby
   allownested
   obey dblogin-target.oby
   stop replicat $OCIGG_REPLICAT_NAME
EOF

  cat <<EOF >start-ocigg-extract.oby
   allownested
   obey dblogin-source.oby
   REGISTER EXTRACT $OCIGG_EXTRACT_NAME DATABASE CONTAINER (PDB1)
   start extract $OCIGG_EXTRACT_NAME
EOF

  cat <<EOF >create-ocigg-extract.oby
   allownested
   obey dblogin-source.oby
   ADD EXTRACT $OCIGG_EXTRACT_NAME, INTEGRATED TRANLOG, BEGIN NOW
   ADD EXTTRAIL gg, EXTRACT $OCIGG_EXTRACT_NAME
EOF

  cat <<EOF >create-ocigg-replicat.oby
   allownested
   obey dblogin-target.oby
   ADD CHECKPOINTTABLE GGADMIN.OCICHECKPOINT
   ADD REPLICAT $OCIGG_REPLICAT_NAME ,INTEGRATED ,EXTTRAIL gg ,BEGIN NOW ,CHECKPOINTTABLE GGADMIN.OCICHECKPOINT
EOF

}

function info-ocigg ()
{
  echo "obey info-ocigg.oby" |adminclient
}


function start-ocigg-extract ()
{
  echo "obey start-ocigg-extract.oby" |adminclient
}

function create-ocigg-extract ()
{
echo "obey create-ocigg-extract.oby" |adminclient
}

function create-ocigg-replicat ()
{
echo "obey create-ocigg-replicat.oby" |adminclient
}

function show-long-running-txns ()
{
sqlplus -s sys/internal as sysdba <<EOSQ
set pages 50 lines 128
col username format a16
col program format a16
col tran_status format a12

SELECT 
  TO_CHAR( START_DATE, 'yyyy/mm/DD HH24:MI:SS') STARTTM
, ROUND(CAST((SYSDATE - START_DATE)AS NUMBER)*24*60,0) AGE
, T.STATUS TRAN_STATUS
, START_SCN
, TO_CHAR( LOGON_TIME, 'yyyy/mm/DD HH24:MI:SS') LOGINTM
, USERNAME
, PROGRAM
, S.STATUS SESS_STATUS
, SID
FROM V\$TRANSACTION T, V\$SESSION S
WHERE S.SADDR = T.SES_ADDR 
and ROUND(CAST((SYSDATE - START_DATE)AS NUMBER)*24*60,0) >30
ORDER BY 1;
EOSQ
}

function get-ggmp-parm-files ()
{
  clear;
  scp GGMP21:migrate-mp19c.vars .
  scp GGMP19:.bashrc GGMP19-bashrc
  source  migrate-mp19c.vars 
  TNS_ADMIN=$(grep TNS_ADMIN GGMP19-bashrc |cut -f 2 -d '=')
  echo $TNS_ADMIN
  cat <<EOF >get-ggmp-parm-files.sh
  $(echo scp GGMP19:$TNS_ADMIN/conf/ogg/$GGMP_EXTRACT_NAME.prm . )
  $(echo scp GGMP19:$TNS_ADMIN/conf/ogg/$GGMP_REPLICAT_NAME.prm . )
EOF
  bash get-ggmp-parm-files.sh

  grep -iv extract $GGMP_EXTRACT_NAME.prm >temp-$GGMP_EXTRACT_NAME.prm
  echo EXTRACT $OCIGG_EXTRACT_NAME >$OCIGG_EXTRACT_NAME.prm
  cat temp-$GGMP_EXTRACT_NAME.prm >>$OCIGG_EXTRACT_NAME.prm

  grep -iv replicat $GGMP_REPLICAT_NAME.prm >temp-$GGMP_REPLICAT_NAME.prm
  echo REPLICAT $OCIGG_REPLICAT_NAME >$OCIGG_REPLICAT_NAME.prm
  cat temp-$GGMP_REPLICAT_NAME.prm >>$OCIGG_REPLICAT_NAME.prm

  echo; echo "The OCIGG replicat parameters are:"
  echo; cat $OCIGG_REPLICAT_NAME.prm; echo; echo; echo

  echo "The OCIGG extract parameters are:"
  echo; cat $OCIGG_EXTRACT_NAME.prm; echo
  read -p "Copy the extract and replicat parameters to a notepad. Press any key to continue" x; echo;
}
 
function get-target-pdb-name ()
{
# Assumes the first SOURCECATALOG or TABLE statement is the PDB to be used for examples
# Get alias from dblogin
# get TNs alaias from credentials
# get pdb name from tnsnames.ora

  TARGET_PDB_NAME=PDB1
  echo export TARGET_PDB_NAME=$TARGET_PDB_NAME >>migrate-mp19c.vars
}
 
function get-source-pdb-name ()
{
# Assumes the first SOURCECATALOG or TABLE statement is the PDB to be used for examples
  
  grep -i sourcecatalog $GGMP_EXTRACT_NAME.prm >null
  if [ $? = 0 ]
  then
    export SOURCE_PDB_NAME=$(grep -i sourcecatalog $GGMP_EXTRACT_NAME.prm |head -1 |cut -f 2 -d ' ')
  else
    export SOURCE_PDB_NAME=$(grep -i table $GGMP_EXTRACT_NAME.prm |head -1 |cut -f 2 -d ' ' |cut -f 1 -d '.')
  fi

  echo export SOURCE_PDB_NAME=$SOURCE_PDB_NAME >>migrate-mp19c.vars
}

function sync-variables ()
{
  create-ocigg-obey-files
  create-ggmp-obey-files
  rm /tmp/sync.zip
  zip /tmp/sync migrate-mp19c.vars *.oby
}

function client-sync-variables ()
{
  echo "rm *.oby migrate-mp19c.vars; unzip /tmp/sync.zip " >sync.sh

  scp GGMP21:/tmp/sync.zip /tmp 
  scp /tmp/sync.zip SOURCE:/tmp
  scp /tmp/sync.zip GGMP19:/tmp
  scp /tmp/sync.zip TARGET:/tmp

  ssh SOURCE 'bash -s' -- <sync.sh
  ssh GGMP19 'bash -s' -- <sync.sh
  ssh TARGET 'bash -s' -- <sync.sh
  
  bash sync.sh
}

function create-example-schema ()
{
  sqlplus -s ggadmin/$PSSWRD@$(hostname):1521/$SOURCE_PDB_NAME.$(hostname -d) <<EOF
  create user GGRTS_BLOG_USER identified by $PSSWRD 
   default tablespace "USERS" temporary tablespace "TEMP";
  alter user GGRTS_BLOG_USER quota unlimited on "USERS";
  grant CONNECT, RESOURCE to GGRTS_BLOG_USER ;
  
  create table GGRTS_BLOG_USER.COUNTRIES
   (    COUNTRY_ID CHAR(2 BYTE) NOT NULL ENABLE,
        COUNTRY_NAME VARCHAR2(40 BYTE),
        REGION_ID NUMBER,
         CONSTRAINT COUNTRY_C_ID_PK PRIMARY KEY (COUNTRY_ID));
EOF
}

function show-migration-status ()
{
sqlplus -s "ggadmin/$PSSWRD@$(hostname):1521/$TARGET_PDB_NAME.$(hostname -d)" <<EOF
  col TIME FORMAT A30
  col PATH FORMAT A20
  col RESTART_AGE FORMAT A28
  col RESTART FORMAT A10
  col HEARTBEAT FORMAT A10
  col REPLICAT FORMAT A10
  set pages 50 lines 200 trim on feed off
  SELECT current_local_ts TIME
  , incoming_path PATH
  , incoming_extract_restart_age RESTART_AGE
  , incoming_extract_restart_csn RESTART
  , incoming_extract_heartbeat_csn HEARTBEAT
  , incoming_replicat_lw_csn REPLICAT
  FROM ggadmin.gg_lag;
EOF
  echo
}

function insert-row-no-commit ()
{
  echo; echo "Leave this terminal session and sqlplus session open until later in the guide";
  echo
  cat <<EOF >insert-row-no-commit.sql
   set exitcommit off
   insert into GGRTS_BLOG_USER.COUNTRIES
   values ( '1', 'China', 1 );
EOF
    
  sqlplus -s ggadmin/$PSSWRD@$(hostname):1521/$SOURCE_PDB_NAME.$(hostname -d) @insert-row-no-commit.sql
}

function insert-row ()
{
# Expecting row sequence number in $1 e.g. 2, 3
  if [ -z $1 ]; then echo "Exiting: No row sequence number"; exit; fi
  optParm=$1
  if [ $optParm = 2 ]; then cname="Germany"; fi
  if [ $optParm = 3 ]; then cname="Canada"; fi

  cat <<EOF >insert-row.sql
   insert into GGRTS_BLOG_USER.COUNTRIES
   values ( $optParm, '$cname', $optParm );
   commit;
EOF
 
  sqlplus -s "ggadmin/$PSSWRD@$(hostname):1521/$SOURCE_PDB_NAME.$(hostname -d)" <<EOSQ
   @insert-row.sql
EOSQ
  echo "Row inserted and commited"
}

function show-rows ()
{
  cat <<EOF >show-rows.sql
  set head off verify off
  select 'SOURCE' from dual;
  set head on
  select b.* from ggrts_blog_user.countries b;
  connect ggadmin/$PSSWRD@GGMPTGT_PDB1
  set head off verify off 
  select 'TARGET' from dual;
  set head on
  select b.* from ggrts_blog_user.countries b; 
  exit
EOF
  sqlplus -s ggadmin/$PSSWRD@GGMPSRC_PDB1 @show-rows
}

# Begin
clear; cd;

# Expecting Process as $1
if [ -z $1 ]; then echo Exiting: No process received; exit; fi
process="$1"

# Expecting optional parameter as $2
optParm="$2"

if [ -f migrate-mp19c.vars ]
then :
else touch migrate-mp19c.vars
fi

source migrate-mp19c.vars

if [ $process = show-long-running-txns ]; then show-long-running-txns; exit; fi
if [ $process = copy-extract-parms ]; then copy-extract-parms $"optParm" ; exit; fi
if [ $process = copy-replicat-parms ]; then copy-replicat-parms $"optParm" ; exit; fi
if [ $process = stop-ggmp ]; then stop-ggmp ; exit; fi
if [ $process = stop-ocigg-replicat ]; then stop-ocigg-replicat ; exit; fi
if [ $process = start-ocigg-replicat ]; then start-ocigg-replicat ; exit; fi
if [ $process = start-ocigg-extract ]; then start-ocigg-extract ; exit; fi
if [ $process = remove-ocigg-replicat-parm ]; then remove-ocigg-replicat-parm ; exit; fi
if [ $process = setup-ggmp21 ]; then setup-ggmp21 ; exit; fi
if [ $process = prompt-for-ocigg-variables ]; then prompt-for-ocigg-variables; exit; fi
if [ $process = create-ocigg-extract ]; then create-ocigg-extract; exit; fi
if [ $process = create-ocigg-replicat ]; then create-ocigg-replicat; exit; fi
if [ $process = get-ggmp-parm-files ]; then get-ggmp-parm-files; exit; fi
if [ $process = create-example-schema ]; then create-example-schema; exit; fi
if [ $process = sync-variables ]; then sync-variables;  exit; fi
if [ $process = client-sync-variables ]; then client-sync-variables;  exit; fi
if [ $process = show-migration-status ]; then show-migration-status;  exit; fi
if [ $process = insert-row-no-commit ]; then insert-row-no-commit ;  exit; fi
if [ $process = insert-row ]; then insert-row $optParm ;  exit; fi
if [ $process = show-rows ]; then show-rows ;  exit; fi
if [ $process = info-ocigg ]; then info-ocigg ;  exit; fi
if [ $process = stop-ggmp ]; then stop-ggmp ;  exit; fi
if [ $process = restart-ocigg-replicat ]; then restart-ocigg-replicat ;  exit; fi
if [ $process = persist-ocigg-variables ]
then 
  persist-ocigg-variables
  find-ocigg-deployment
  create-ocigg-obey-files 
  exit
fi

if [ $process = prompt-for-ggmp-variables ]; then prompt-for-ggmp-variables; exit; fi
if [ $process = persist-ggmp-variables ]
then 
  persist-ggmp-variables
  create-ggmp-obey-files 
  exit
fi
## if [ $process = find-ocigg-deployment ]; then find-ocigg-deployment ; exit; fi

echo "Exiting: Unknown process"



